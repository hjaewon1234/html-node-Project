addplaylist = document.getElementById("add-playlist");

addplaylist.onclick = function () {
  console.log("hi");
};

function removelist() {
  console.log("dot작동");
}
