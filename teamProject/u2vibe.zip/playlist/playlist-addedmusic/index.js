addplaylist = document.getElementById("add-playlist");

addplaylist.onclick = function () {
  console.log("hi");
};

function dropdown() {
  console.log("dot작동");
}
