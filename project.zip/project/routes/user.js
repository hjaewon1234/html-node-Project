const router = require("express").Router();
const { User } = require("../models/index.js");
// DataBase에 User테이블 연동, 연결

// GET / POST / PUT / PATCH / DELETE

module.exports = router;
